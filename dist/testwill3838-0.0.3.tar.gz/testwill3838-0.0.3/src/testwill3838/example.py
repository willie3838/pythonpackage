# Token: pypi-AgEIcHlwaS5vcmcCJDJmMjdhY2FiLTBjNjEtNDE5Yy1iNzU1LTkwNWM0ZDI0MGYyMwACKlszLCJiM2JiZmY3My0yNDNkLTQ2YzctYTZjMS1mZGYwMGFkYWQ4ZGIiXQAABiAaO4oyK_I9clcnbvSLmHZQv8rtqAsqKW1HmzFWGB-jbQ
def add_one(number):
    print("v1")
    return number + 1
